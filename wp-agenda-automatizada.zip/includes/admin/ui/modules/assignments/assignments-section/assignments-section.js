/**
 * Assignments Section - Assignments Management
 * 
 * Handles UI logic for managing assignments (staff + zone + service + time)
 * Renders assignments as collapsible cards with delete functionality
 */

(function() {
    'use strict';

    // Store root element reference for reuse
    let assignmentsRoot = null;

    /**
     * Initialize the assignments section
     */
    function initAssignmentsSection() {
        assignmentsRoot = document.getElementById('aa-assignments-root');
        
        // Fail safely if root doesn't exist
        if (!assignmentsRoot) {
            console.warn('[Assignments Section] Root element #aa-assignments-root not found');
            return;
        }

        // Load and render assignments
        loadAssignments();
    }

    /**
     * Load assignments from server via AJAX
     */
    function loadAssignments() {
        // Get ajaxurl from global data
        const ajaxurl = (window.AA_ASSIGNMENTS_DATA && window.AA_ASSIGNMENTS_DATA.ajaxurl) 
            || window.ajaxurl 
            || '/wp-admin/admin-ajax.php';

        // Prepare FormData for AJAX request
        const formData = new FormData();
        formData.append('action', 'aa_get_assignments');

        // Show loading state
        assignmentsRoot.innerHTML = '<p class="text-sm text-gray-500">Cargando asignaciones...</p>';

        // Make AJAX request
        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success && data.data && data.data.assignments) {
                // Filtrar asignaciones para mostrar solo las de fecha actual o futura
                let filteredAssignments = data.data.assignments;
                
                // Función helper para filtrar fechas (fallback si DateUtils no está disponible)
                function filterByCurrentAndFutureDates(items, dateField) {
                    if (!Array.isArray(items) || items.length === 0) {
                        return [];
                    }
                    
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const todayYmd = today.getFullYear() + '-' + 
                                    String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                                    String(today.getDate()).padStart(2, '0');
                    
                    return items.filter(function(item) {
                        if (!item || !item[dateField]) {
                            return false;
                        }
                        
                        const itemDateStr = item[dateField];
                        if (!itemDateStr || typeof itemDateStr !== 'string') {
                            return false;
                        }
                        
                        // Comparar fechas (YYYY-MM-DD se puede comparar como string)
                        return itemDateStr >= todayYmd;
                    });
                }
                
                // Intentar usar DateUtils si está disponible, sino usar fallback
                if (window.DateUtils && typeof window.DateUtils.filterCurrentAndFutureDates === 'function') {
                    filteredAssignments = window.DateUtils.filterCurrentAndFutureDates(
                        data.data.assignments,
                        'assignment_date'
                    );
                    console.log('[Assignments Section] Asignaciones filtradas: ' + filteredAssignments.length + ' de ' + data.data.assignments.length + ' (solo actuales o futuras)');
                } else {
                    // Fallback: filtrar manualmente
                    filteredAssignments = filterByCurrentAndFutureDates(data.data.assignments, 'assignment_date');
                    console.log('[Assignments Section] Asignaciones filtradas (fallback): ' + filteredAssignments.length + ' de ' + data.data.assignments.length + ' (solo actuales o futuras)');
                }
                
                renderAssignments(filteredAssignments);
            } else {
                console.error('[Assignments Section] Error en respuesta:', data);
                assignmentsRoot.innerHTML = '<p class="text-sm text-red-500">Error al cargar las asignaciones.</p>';
            }
        })
        .catch(function(error) {
            console.error('[Assignments Section] Error en petición AJAX:', error);
            assignmentsRoot.innerHTML = '<p class="text-sm text-red-500">Error al conectar con el servidor.</p>';
        });
    }

    /**
     * Render assignments as collapsible cards
     * @param {Array} assignments - Array of assignment objects
     */
    function renderAssignments(assignments) {
        if (!assignments || assignments.length === 0) {
            assignmentsRoot.innerHTML = '<p class="text-sm text-gray-500">No hay asignaciones registradas.</p>';
            return;
        }

        // Build HTML for assignments list
        let html = '<div class="space-y-3">';
        
        assignments.forEach(function(assignment) {
            const assignmentId = parseInt(assignment.id);
            const date = formatDate(assignment.assignment_date);
            const timeRange = formatTime(assignment.start_time) + ' - ' + formatTime(assignment.end_time);
            
            // Card container with data-aa-card attribute for collapsible behavior
            html += '<div class="aa-assignment-card border border-gray-200 rounded-lg overflow-hidden" data-aa-card data-id="' + assignmentId + '">';
            
            // Card header (clickable to expand/collapse)
            html += '<div class="aa-assignment-header flex items-center gap-3 p-4 bg-gray-50 cursor-pointer" data-aa-card-toggle>';
            
            // Icon
            html += '<span class="flex items-center justify-center w-10 h-10 rounded-lg bg-purple-100 text-purple-600 flex-shrink-0">';
            html += '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">';
            html += '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/>';
            html += '</svg>';
            html += '</span>';
            
            // Header info
            html += '<div class="flex-1 min-w-0">';
            html += '<div class="text-sm font-medium text-gray-900">' + escapeHtml(date) + '</div>';
            html += '<div class="text-xs text-gray-500">' + escapeHtml(timeRange) + '</div>';
            html += '</div>';
            
            // Toggle switch
            const isActive = assignment.status === 'active';
            html += '<div class="ml-auto relative">';
            html += '<label class="flex items-center cursor-pointer">';
            html += '<input type="checkbox" ';
            html += 'class="toggle-assignment-active peer sr-only" ';
            html += 'data-id="' + assignmentId + '" ';
            html += 'data-status="' + (assignment.status || 'active') + '" ';
            if (isActive) {
                html += 'checked ';
            }
            html += '/>';
            html += '<div class="w-9 h-5 bg-gray-300 peer-checked:bg-blue-500 rounded-full transition-colors duration-200"></div>';
            html += '<div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-200 peer-checked:translate-x-4"></div>';
            html += '</label>';
            html += '</div>';
            
            html += '</div>'; // End header
            
            // Card body (hidden by default, shown when expanded)
            html += '<div class="aa-assignment-body hidden p-4 bg-white border-t border-gray-100">';
            
            // Assignment details grid
            html += '<div class="grid grid-cols-2 gap-4 mb-4">';
            
            // Responsable (staff name)
            html += '<div>';
            html += '<span class="text-xs text-gray-500 block">Responsable</span>';
            html += '<span class="text-sm font-medium text-gray-900">' + escapeHtml(assignment.staff_name || '-') + '</span>';
            html += '</div>';
            
            // Zona (service area name)
            html += '<div>';
            html += '<span class="text-xs text-gray-500 block">Zona</span>';
            html += '<span class="text-sm font-medium text-gray-900">' + escapeHtml(assignment.service_area_name || '-') + '</span>';
            html += '</div>';
            
            // Servicio (services from pivot table)
            html += '<div>';
            html += '<span class="text-xs text-gray-500 block">Servicios</span>';
            html += '<div class="aa-assignment-services-' + assignmentId + ' text-sm font-medium text-gray-900">';
            html += '<span class="text-gray-400">Cargando...</span>';
            html += '</div>';
            html += '</div>';
            
            // Capacidad (capacity)
            html += '<div>';
            html += '<span class="text-xs text-gray-500 block">Capacidad</span>';
            html += '<span class="text-sm font-medium text-gray-900">' + escapeHtml(assignment.capacity || '1') + '</span>';
            html += '</div>';
            
            html += '</div>'; // End grid
            
            // Hide button
            html += '<div class="pt-3 border-t border-gray-100">';
            html += '<button type="button" class="aa-delete-assignment px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-medium rounded-lg transition-colors" data-id="' + assignmentId + '">';
            html += '<svg class="w-4 h-4 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">';
            html += '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>';
            html += '</svg>';
            html += 'Ocultar';
            html += '</button>';
            html += '</div>';
            
            html += '</div>'; // End body
            
            html += '</div>'; // End card
        });
        
        html += '</div>';

        assignmentsRoot.innerHTML = html;
        
        // Setup card toggle handlers
        setupCardToggleHandlers();
        
        // Setup delete handlers
        setupDeleteHandlers();
        
        // Setup checkbox handlers (prevent toggle when clicking checkbox)
        setupCheckboxHandlers();
        
        // Load services for all assignments
        loadAssignmentServices(assignments);
    }

    /**
     * Setup handlers for card toggle (expand/collapse)
     */
    function setupCardToggleHandlers() {
        const toggles = assignmentsRoot.querySelectorAll('[data-aa-card-toggle]');
        
        toggles.forEach(function(toggle) {
            toggle.addEventListener('click', function(event) {
                // Don't toggle if clicking on a button, checkbox, or label inside
                const target = event.target;
                if (target.closest('button') || 
                    target.closest('input[type="checkbox"]') || 
                    target.closest('label') ||
                    target.closest('.toggle-assignment-active')) {
                    return;
                }
                
                const card = this.closest('[data-aa-card]');
                if (!card) return;
                
                const body = card.querySelector('.aa-assignment-body');
                
                if (body) {
                    body.classList.toggle('hidden');
                }
            });
        });
    }

    /**
     * Setup handlers for checkbox toggles
     * Prevents the card toggle from firing when clicking the checkbox
     * Also handles status updates when checkbox is toggled
     */
    function setupCheckboxHandlers() {
        const checkboxes = assignmentsRoot.querySelectorAll('.toggle-assignment-active');
        
        checkboxes.forEach(function(checkbox) {
            // Prevent event propagation on checkbox and label
            checkbox.addEventListener('click', function(event) {
                event.stopPropagation();
            });
            
            // Handle change event to update status
            checkbox.addEventListener('change', function() {
                const assignmentId = parseInt(this.getAttribute('data-id'));
                const previousStatus = this.getAttribute('data-status');
                const newStatus = this.checked ? 'active' : 'inactive';
                
                // Update status via AJAX
                handleToggleAssignment(assignmentId, newStatus, previousStatus, this);
            });
            
            // Also prevent on the label wrapper
            const label = checkbox.closest('label');
            if (label) {
                label.addEventListener('click', function(event) {
                    // Only stop propagation if clicking directly on the label, not the checkbox itself
                    if (event.target === label || event.target.closest('.w-11') || event.target.closest('.absolute')) {
                        event.stopPropagation();
                    }
                });
            }
        });
    }
    
    /**
     * Handle assignment status toggle
     * @param {number} assignmentId - Assignment ID
     * @param {string} newStatus - New status ('active' or 'inactive')
     * @param {string} previousStatus - Previous status for rollback on error
     * @param {HTMLElement} checkbox - The checkbox element
     */
    function handleToggleAssignment(assignmentId, newStatus, previousStatus, checkbox) {
        const ajaxurl = (window.AA_ASSIGNMENTS_DATA && window.AA_ASSIGNMENTS_DATA.ajaxurl) 
            || window.ajaxurl 
            || '/wp-admin/admin-ajax.php';

        const formData = new FormData();
        formData.append('action', 'aa_update_assignment_status');
        formData.append('id', assignmentId);
        formData.append('status', newStatus);

        // Make AJAX request
        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                // Update data attribute to reflect new state
                checkbox.setAttribute('data-status', newStatus);
                console.log('[Assignments Section] Status actualizado para asignación ' + assignmentId + ': ' + newStatus);
            } else {
                // Revert checkbox state on error
                checkbox.checked = (previousStatus === 'active');
                console.error('[Assignments Section] Error al actualizar status:', data.message);
            }
        })
        .catch(function(error) {
            // Revert checkbox state on error
            checkbox.checked = (previousStatus === 'active');
            console.error('[Assignments Section] Error en petición AJAX:', error);
        });
    }

    /**
     * Setup handlers for delete buttons
     */
    function setupDeleteHandlers() {
        const deleteButtons = assignmentsRoot.querySelectorAll('.aa-delete-assignment');
        
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function(event) {
                event.stopPropagation();
                
                const assignmentId = parseInt(this.getAttribute('data-id'));
                if (assignmentId > 0) {
                    handleDeleteAssignment(assignmentId);
                }
            });
        });
    }

    /**
     * Handle assignment deletion
     * @param {number} id - Assignment ID to delete
     */
    function handleDeleteAssignment(id) {
        // Simple confirmation
        if (!confirm('¿Estás seguro de ocultar esta asignación?')) {
            return;
        }
        
        // Get ajaxurl from global data
        const ajaxurl = (window.AA_ASSIGNMENTS_DATA && window.AA_ASSIGNMENTS_DATA.ajaxurl) 
            || window.ajaxurl 
            || '/wp-admin/admin-ajax.php';

        // Prepare FormData for AJAX request
        const formData = new FormData();
        formData.append('action', 'aa_delete_assignment');
        formData.append('id', id);

        // Make AJAX request
        fetch(ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                // Re-render the list
                loadAssignments();
            } else {
                console.error('[Assignments Section] Error al ocultar:', data);
                alert('Error al ocultar la asignación');
            }
        })
        .catch(function(error) {
            console.error('[Assignments Section] Error en petición AJAX:', error);
            alert('Error al conectar con el servidor');
        });
    }

    /**
     * Format date for display
     * @param {string} dateStr - Date string in YYYY-MM-DD format
     * @returns {string} Formatted date
     */
    function formatDate(dateStr) {
        if (!dateStr) return '-';
        
        try {
            const parts = dateStr.split('-');
            if (parts.length !== 3) return dateStr;
            
            const year = parts[0];
            const month = parts[1];
            const day = parts[2];
            
            // Return in DD/MM/YYYY format
            return day + '/' + month + '/' + year;
        } catch (e) {
            return dateStr;
        }
    }

    /**
     * Format time for display
     * @param {string} timeStr - Time string in HH:MM:SS format
     * @returns {string} Formatted time (HH:MM)
     */
    function formatTime(timeStr) {
        if (!timeStr) return '-';
        
        try {
            const parts = timeStr.split(':');
            if (parts.length < 2) return timeStr;
            
            return parts[0] + ':' + parts[1];
        } catch (e) {
            return timeStr;
        }
    }

    /**
     * Load services for all assignments
     * @param {Array} assignments - Array of assignment objects
     */
    function loadAssignmentServices(assignments) {
        if (!assignments || assignments.length === 0) {
            return;
        }
        
        // Get ajaxurl from global data
        const ajaxurl = (window.AA_ASSIGNMENTS_DATA && window.AA_ASSIGNMENTS_DATA.ajaxurl) 
            || window.ajaxurl 
            || '/wp-admin/admin-ajax.php';
        
        // Load services for each assignment
        assignments.forEach(function(assignment) {
            const assignmentId = parseInt(assignment.id);
            if (!assignmentId || assignmentId <= 0) {
                return;
            }
            
            // Prepare FormData for AJAX request
            const formData = new FormData();
            formData.append('action', 'aa_get_assignment_services');
            formData.append('assignment_id', assignmentId);
            
            // Make AJAX request
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.success && data.data && data.data.services) {
                    updateAssignmentServicesUI(assignmentId, data.data.services);
                } else {
                    // No services found or error
                    updateAssignmentServicesUI(assignmentId, []);
                }
            })
            .catch(function(error) {
                console.error('[Assignments Section] Error al cargar servicios para asignación ' + assignmentId + ':', error);
                updateAssignmentServicesUI(assignmentId, []);
            });
        });
    }

    /**
     * Update UI with assignment services
     * @param {number} assignmentId - ID of the assignment
     * @param {Array} services - Array of service objects with id and name
     */
    function updateAssignmentServicesUI(assignmentId, services) {
        const servicesContainer = assignmentsRoot.querySelector('.aa-assignment-services-' + assignmentId);
        if (!servicesContainer) {
            return;
        }
        
        if (!services || services.length === 0) {
            servicesContainer.innerHTML = '<span class="text-gray-400">Sin servicios</span>';
            return;
        }
        
        // Build services list
        let html = '';
        if (services.length === 1) {
            html = '<span>' + escapeHtml(services[0].name) + '</span>';
        } else {
            // Multiple services - show as comma-separated list
            const serviceNames = services.map(function(service) {
                return escapeHtml(service.name);
            });
            html = '<span>' + serviceNames.join(', ') + '</span>';
        }
        
        servicesContainer.innerHTML = html;
    }

    /**
     * Escape HTML to prevent XSS
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        const div = document.createElement('div');
        div.textContent = String(text);
        return div.innerHTML;
    }

    // Initialize on DOMContentLoaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAssignmentsSection);
    } else {
        // DOM already ready
        initAssignmentsSection();
    }

    // Expose loadAssignments globally for modal to reload list
    window.loadAssignments = loadAssignments;
    window.reloadAssignmentsList = loadAssignments;

    // Listen for assignment created event
    document.addEventListener('aa-assignment-created', function() {
        loadAssignments();
    });

})();
